<article class="page">
	
	<h2><?php the_title(); ?></h2>

	<?php the_content(); ?>

</article>