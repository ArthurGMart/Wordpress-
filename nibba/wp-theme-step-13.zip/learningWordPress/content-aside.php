<article class="post post-aside">
	
	<p class="mini-meta"><a href="<?php the_permalink(); ?>"><?php the_author(); ?> @ <?php the_time('F j, Y'); ?></a></p>
	<?php the_content(); ?>
	
</article>